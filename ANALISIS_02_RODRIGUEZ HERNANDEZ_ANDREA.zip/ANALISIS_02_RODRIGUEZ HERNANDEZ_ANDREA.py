import csv

with open("synergy_logistics_database.csv","r") as archivo:

  lector = csv.reader(archivo)  #Leer el archivo

  i=-1
  e=0

  transportes = list()

#crear lista para exportaciones
  sea_e = list()
  road_e = list()
  rail_e = list()
  air_e = list()

#crear lista para importaciones
  sea_i = list()
  road_i = list()
  rail_i = list()
  air_i = list()
  
#ciclo para leer línea por línea y separar exportaciones de importaciones  
  for linea in lector:  
    transportes.append(linea[7])
    i+=1
    if linea[1] == "Exports":
      e+=1
      if linea[7] == "Sea":
        sea_e.append(int(linea[9]))
      if linea[7] == "Air":
        air_e.append(int(linea[9]))
      if linea[7] == "Road":
        road_e.append(int(linea[9]))
      if linea[7] == "Rail":
        rail_e.append(int(linea[9]))
    else:
      if linea[7] == "Sea":
        sea_i.append(int(linea[9]))
      if linea[7] == "Air":
        air_i.append(int(linea[9]))
      if linea[7] == "Road":
        road_i.append(int(linea[9]))
      if linea[7] == "Rail":
        rail_i.append(int(linea[9]))
  
  importaciones = i-e

  print(" -EL siguiente programa muestra el análisis para los medios de transporte utilizador por Synergy Logistics- \n \n")

#utilicé conjuntos para ver cuales medios de transporte había sin que se repitieran
  medios_transporte = set(transportes)
  medios_transporte.remove('transport_mode')
  print(f"Los medios de transporte utilizados son: {medios_transporte}; es decir, por aire, mar, carretera y ferrocarril. \n")

  print(f"El archivo cuenta con {i} datos, de los cuales {e} son exportaciones y {importaciones} son importaciones. \n")
  

#usando len obtengo la cantidad de veces que se repite el medio de transporte, y con sum el total de los valores
  print(f"Exportaciones: \n Aire {len(air_e)}, valor = {sum(air_e)} \n Mar {len(sea_e)}, valor = {sum(sea_e)} \n Carretera {len(road_e)}, valor = {sum(road_e)} \n Ferrocarril {len(rail_e)}, valor = {sum(rail_e)} \n")

  valor_exportaciones = (("Aire", sum(air_e)),( "Mar",sum(sea_e)), ("Carretera",sum(road_e)),( "Ferrocarril",sum(rail_e)))

  valores_exp = sorted(valor_exportaciones, key=lambda item: (item[1]), reverse=True)
  print("A continuación se muestran los medios de transporte con mayores valores para exportaciones:")
  
  
  for j in range(len(valores_exp)):
    print(valores_exp[j][0])



  print(f"\n\nImportaciones: \n Aire {len(air_i)}, valor = {sum(air_i)} \n Mar {len(sea_i)}, valor = {sum(sea_i)} \n Carretera {len(road_i)}, valor = {sum(road_i)} \n Ferrocarril {len(rail_i)}, valor = {sum(rail_i)} \n")

  valor_importaciones = (("Aire", sum(air_i)),( "Mar",sum(sea_i)), ("Carretera",sum(road_i)),( "Ferrocarril",sum(rail_i)))

  valores_imp = sorted(valor_importaciones, key=lambda item: (item[1]), reverse=True)
  print("A continuación se muestran los medios de transporte con mayores valores para importaciones:")
  
  
  for j in range(len(valores_imp)):
    print(valores_imp[j][0])


#función lambda para sumar, usada para conocer el valor total de exportaciones e importaciones
  sumar = lambda x,y: x+y

  #importación y exportación
  valor_total = (("Aire",sumar(sum(air_e),sum(air_i))), ("Mar",sumar(sum(sea_e),sum(sea_i))),( "Carretera",sumar(sum(road_e),sum(road_i))), ("Ferrocarril",sumar(sum(rail_e),sum(rail_i))))  

  
  print(f"\n \nValores totales \n Aire: {sumar(sum(air_e),sum(air_i))} \n Mar: {sumar(sum(sea_e),sum(sea_i))} \n Carretera: {sumar(sum(road_e),sum(road_i))} \n Ferrocarril: {sumar(sum(rail_e),sum(rail_i))} \n")


  valores = sorted(valor_total, key=lambda item: (item[1]), reverse=True)
  print("A continuación se muestran los medios de transporte con mayores valores:")
  
  for j in range(len(valores)):
    print(valores[j][0])