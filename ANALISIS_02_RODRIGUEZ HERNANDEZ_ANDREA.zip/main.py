import csv

with open("synergy_logistics_database.csv","r") as archivo:
  lector = csv.reader(archivo)  #Leer el archivo como lista

  print(" -EL siguiente programa muestra el análisis para los medios de transporte utilizador por Synergy Logistics- \n \n")

  print("Información disponible: \n 1. Rutas de importación y exportación \n 2. Medio de transporte utilizado \n 3. Valor total de importaciones y exportaciones\n")

  info = input("Ingrese el número de la información que quiere consultar:")

  while info != "1" and info != "2" and info != "3":
    print("\n Error")
    info = input("Ingrese la información que quiere consultar:")


#OPCION 1: RUTAS
  if info == "1":
    rutas_exp = list()
    rutas_imp = list()

    datos = list()
   

    #ciclo for para extraer las rutas de exportacion e importación
    for linea in lector: 
      if linea[1] == "Exports":
        ruta_exp = (linea[2], linea[3])  #(orgien,destino)
        rutas_exp.append(ruta_exp)

      else:
        origen_imp = linea[2]
        destino_imp = linea[3]
        ruta_imp = (origen_imp, destino_imp)
        rutas_imp.append(ruta_imp)


  #utilicé conjuntos para visualizar las rutas sin que se repitieran
    rutas_conjunto_exp = set(rutas_exp)
    rutas_conjunto_imp = set(rutas_imp)
    
    print(f"\nSe tienen {len(rutas_conjunto_exp)} diferentes rutas de exportación y {len(rutas_conjunto_imp)} diferentes rutas de importación")

    print("La empresa sólo quiere enfocarse en 10 rutas (10 de 144 es sólo el 6.9%), por lo tanto, no me concentraré en esta opción.  \n NOTA: Vea opción 2.")








#OPCION 2: MEDIOS DE TRANSPORTE
  elif info == "2":

    i=-1
    e=0

    transportes = list()

  #crear lista para exportaciones
    sea_e = list()
    road_e = list()
    rail_e = list()
    air_e = list()

  #crear lista para importaciones
    sea_i = list()
    road_i = list()
    rail_i = list()
    air_i = list()
    
  #ciclo para leer línea por línea y separar exportaciones de importaciones  
    for linea in lector:  
      transportes.append(linea[7])
      i+=1
      if linea[1] == "Exports":
        e+=1
        if linea[7] == "Sea":
          sea_e.append(int(linea[9]))
        if linea[7] == "Air":
          air_e.append(int(linea[9]))
        if linea[7] == "Road":
          road_e.append(int(linea[9]))
        if linea[7] == "Rail":
          rail_e.append(int(linea[9]))
      else:
        if linea[7] == "Sea":
          sea_i.append(int(linea[9]))
        if linea[7] == "Air":
          air_i.append(int(linea[9]))
        if linea[7] == "Road":
          road_i.append(int(linea[9]))
        if linea[7] == "Rail":
          rail_i.append(int(linea[9]))
    
    importaciones = i-e


  #utilicé conjuntos para ver cuales medios de transporte había sin que se repitieran
    medios_transporte = set(transportes)
    medios_transporte.remove('transport_mode')
    print(f"\n \n Los medios de transporte utilizados son: {medios_transporte}; es decir, por aire, mar, carretera y ferrocarril. \n")

    print(f"El archivo cuenta con {i} datos, de los cuales {e} son exportaciones y {importaciones} son importaciones. \n")
    


    #función lambda para sumar, usada para conocer el valor total de exportaciones e importaciones
    sumar = lambda x,y: x+y
    
    sumar2 = lambda a,b,c,d: a+b+c+d

    total_ganancias_exp = sumar2(sum(air_e),sum(sea_e),sum(road_e),sum(rail_e))

    total_ganancias_imp = sumar2(sum(air_i),sum(sea_i),sum(road_i),sum(rail_i))



  #usando len obtengo la cantidad de veces que se repite el medio de transporte, y con sum el total de los valores


    print(f"EXPORTACIONES: \n Aire {len(air_e)}, valor = {sum(air_e)} \n Mar {len(sea_e)}, valor = {sum(sea_e)} \n Carretera {len(road_e)}, valor = {sum(road_e)} \n Ferrocarril {len(rail_e)}, valor = {sum(rail_e)} \n")

    print(f"\nTotal de valor para exportaciones: {total_ganancias_exp}, donde el 80% es: {(80*total_ganancias_exp)/100}\n ")


    valor_exportaciones = (("Aire", sum(air_e)),( "Mar",sum(sea_e)), ("Carretera",sum(road_e)),( "Ferrocarril",sum(rail_e)))

    valores_exp = sorted(valor_exportaciones, key=lambda item: (item[1]), reverse=True)
    print("A continuación se muestran los medios de transporte con mayores valores para exportaciones:")
    
    
    for j in range(len(valores_exp)):
      print(valores_exp[j][0])



    print(f"\n\nIMPORTACIONES: \n Aire {len(air_i)}, valor = {sum(air_i)} \n Mar {len(sea_i)}, valor = {sum(sea_i)} \n Carretera {len(road_i)}, valor = {sum(road_i)} \n Ferrocarril {len(rail_i)}, valor = {sum(rail_i)} \n")

    print(f"\nTotal de valor para importaciones: {total_ganancias_imp}, donde el 80% es: {(80*total_ganancias_imp)/100}\n")


    valor_importaciones = (("Aire", sum(air_i)),( "Mar",sum(sea_i)), ("Carretera",sum(road_i)),( "Ferrocarril",sum(rail_i)))

    valores_imp = sorted(valor_importaciones, key=lambda item: (item[1]), reverse=True)
    print("A continuación se muestran los medios de transporte con mayores valores para importaciones:")
    
    
    for j in range(len(valores_imp)):
      print(valores_imp[j][0])


 
    
    #importación y exportación
    valor_total = (("Aire",sumar(sum(air_e),sum(air_i))), ("Mar",sumar(sum(sea_e),sum(sea_i))),( "Carretera",sumar(sum(road_e),sum(road_i))), ("Ferrocarril",sumar(sum(rail_e),sum(rail_i))))  

    
    print(f"\n \nValores totales {total_ganancias_exp+total_ganancias_imp} \n Aire: {sumar(sum(air_e),sum(air_i))} \n Mar: {sumar(sum(sea_e),sum(sea_i))} \n Carretera: {sumar(sum(road_e),sum(road_i))} \n Ferrocarril: {sumar(sum(rail_e),sum(rail_i))} \n")


    valores = sorted(valor_total, key=lambda item: (item[1]), reverse=True)
    print("A continuación se muestran los medios de transporte con mayores valores:")
    
    for j in range(len(valores)):
      print(valores[j][0])
  

#OPCION 3: VALOR TOTAL
  elif info == "3":
    print("\nLa empresa quiere poner sus esfuerzos en los países que le generan el 80% del valor de las exportaciones e importaciones, pero en base a lo que obtuve en la opción 2, no creo que sea la mejor opción, por lo tanto no me concentraré aquí. \n NOTA: Vea opción 2.")
